
  package com.pns.bank.service;
  
  
  import org.springframework.stereotype.Service;
  
  @Service public class CountryRelationImpl implements CountryRelationI {
  
 /* @Override public List<Country> addCountry(Country country) {
  
  HashSet set = new HashSet();
  
  Country list = new Country();
  
  list.setCountry_code("+91"); list.setCountry_id(1);
  list.setCountry_name("india");
  
  list.setCountry_code("+1"); list.setCountry_id(2);
  list.setCountry_name("USA"); set.add(list); return (List<Country>) list;
  
  }
  
  
  for(Object o:set) { Country emp2 = (Country)o;
  System.out.println(emp2.getCountry_id());
  System.out.println(emp2.getCountry_code());
  System.out.println(emp2.getCountry_name()); }
  
  }
 */
  }