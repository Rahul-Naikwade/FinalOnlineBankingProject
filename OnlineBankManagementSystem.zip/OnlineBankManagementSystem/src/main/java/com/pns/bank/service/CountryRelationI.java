package com.pns.bank.service;

public interface CountryRelationI {
	
	/* public List<Country> addCountry(Country country); */
	

}
