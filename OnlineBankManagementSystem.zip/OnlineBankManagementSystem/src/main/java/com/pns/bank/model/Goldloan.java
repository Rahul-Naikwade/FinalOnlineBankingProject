package com.pns.bank.model;

public class Goldloan {

}
