package com.pns.bank.exception;

public class NoDataFoundException extends Exception {

	public NoDataFoundException(String msg) {
		super(msg);

	}

}
