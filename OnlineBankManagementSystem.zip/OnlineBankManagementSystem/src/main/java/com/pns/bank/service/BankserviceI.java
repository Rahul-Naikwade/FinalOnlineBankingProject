package com.pns.bank.service;

public interface BankserviceI {
	

}
